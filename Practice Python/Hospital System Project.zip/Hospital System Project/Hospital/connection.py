import pyodbc

conn = pyodbc.connect(
    'DRIVER={SQL SERVER};'
    'SERVER=PRANATHI;'
    'DATABASE=HospitalDB;'
    'Trusted_Connection=yes;'
)