from Hospital.specialization import Specialization
from utility import input_is_valid


class OperationsManager:
    def __init__(self):
        self.specs = []

    def print_menu(self):
        print("Program Options: ")
        messages = [
            '1) Add new patients',
            '2) Print all patients',
            '3) Get next patient',
            '4) Remove a leaving patient',
            '5) End the program'
        ]
        print('\n'.join(messages))
        msg = f"Enter your choice from 1 to {len(messages)} \n"
        return input_is_valid(msg, 1, len(messages))

    def run(self):
        choice = self.print_menu()
        while True:
            if choice == 1:
                spec_name = str(input("Enter specialization: "))
                patient_name = str(input("Enter patient name: "))
                patient_status = int(input("Enter status (0 normal / 1 urgent / 2 super urgent): "))

                spec_obj = self.get_or_create_spec(spec_name)
                spec_obj.add_new_patient(patient_name, patient_status)

            elif choice == 2:
                if not self.specs:
                    print("No specializations available yet.")
                for spec in self.specs:
                    print(f'{spec.name}: There are {len(spec.queue)} patients')
                    spec.print_patients()

            elif choice == 3:
                spec_name = str(input("Enter specialization: "))
                spec_obj = self.find_spec(spec_name)
                if spec_obj:
                    spec_obj.get_next_patient()
                else:
                    print("There is no Specialization with this name")

            elif choice == 4:
                spec_name = str(input("Enter specialization: "))
                patient_name = str(input("Enter patient name: "))
                spec_obj = self.find_spec(spec_name)
                if spec_obj:
                    removed = spec_obj.remove_patient(patient_name)
                    if not removed:
                        print("No patient with such a name in this Specialization!")
                    else:
                        print(f"{patient_name} has been removed.")
                        spec_obj.print_patients()
                else:
                    print("Specialization not found.")

            elif choice == 5:
                print("Exiting Program...")
                break

            else:
                print("Invalid choice. Please select a valid option.")
            choice = self.print_menu()

    def get_or_create_spec(self, spec_name):
        for spec in self.specs:
            if spec.name == 'Specialization ' + spec_name:
                return spec
        new_spec = Specialization(spec_name)
        self.specs.append(new_spec)
        return new_spec

    def find_spec(self, spec_name):
        for spec in self.specs:
            if spec.name == 'Specialization ' + spec_name:
                return spec
        return None
