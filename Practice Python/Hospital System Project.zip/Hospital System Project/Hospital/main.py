from operations_manager import *
from utility import *

if __name__ == '__main__':
    main = OperationsManager()
    main.run()
