from Hospital.patient import *
from Hospital.connection import conn

cursor = conn.cursor()

class Specialization:
    MAX_CAPACITY = 10
    PATIENT_STATUS_NUMBERS = [0, 1, 2]

    def __init__(self, name):
        self.name = 'Specialization ' + name
        self.queue = []

        cursor.execute("SELECT Id FROM Specializations WHERE Name = ?", self.name)
        row = cursor.fetchone()
        if row:
            self.spec_id = row[0]
        else:
            cursor.execute("INSERT INTO Specializations (Name) VALUES (?)", self.name)
            cursor.execute("SELECT SCOPE_IDENTITY()")
            self.spec_id = int(cursor.fetchone()[0])
            conn.commit()

        self.load_patients()

    def load_patients(self):
        self.queue = []
        cursor.execute("SELECT Name, Status FROM Patients WHERE specialization_id = ?", self.spec_id)
        rows = cursor.fetchall()
        for row in rows:
            self.queue.append(Patient(row[0], row[1]))
        self.queue.sort(key=lambda x: x.status, reverse=True)

    def add_new_patient(self, name, status):
        if len(self.queue) >= self.MAX_CAPACITY:
            print("Apologies, the queue is full for this specialization.")
            return

        if status not in self.PATIENT_STATUS_NUMBERS:
            print("Invalid status. Status should be 0 (normal), 1 (urgent), or 2 (super-urgent).")
            return

        new_pat = Patient(name, status)
        cursor.execute(
            "INSERT INTO Patients (Name, Status, specialization_id) VALUES (?, ?, ?)",
            new_pat.name, new_pat.status, self.spec_id
        )
        conn.commit()

        self.queue.append(new_pat)
        self.queue.sort(key=lambda x: x.status, reverse=True)
        print(f"Patient: {new_pat.name} is {self.format_patient_status(new_pat.status)}")

    def get_next_patient(self):
        if len(self.queue) == 0:
            print("The Queue is empty")
            return

        next_patient = self.queue.pop(0)

        cursor.execute(
            "DELETE FROM Patients WHERE Name = ? AND Status = ? AND specialization_id = ?",
            next_patient.name, next_patient.status, self.spec_id
        )
        conn.commit()

        print(f"{next_patient.name}, Please go with the Dr")

    def remove_patient(self, name):

        patients_to_remove = [patient for patient in self.queue if patient.name == name]
        for patient in patients_to_remove:
            self.queue.remove(patient)
        cursor.execute(
            "DELETE FROM Patients WHERE Name = ? AND specialization_id = ?",
            name, self.spec_id
        )
        conn.commit()

        return len(patients_to_remove) > 0

    def print_patients(self):
        if not self.queue:
            print("No patients in this specialization.")
        for patient in self.queue:
            print(f"Patient: {patient.name} is {self.format_patient_status(patient.status)}")

    def is_full(self):
        return len(self.queue) >= self.MAX_CAPACITY

    def __str__(self):
        return f"{self.name}: There are {len(self.queue)} patients"

    @staticmethod
    def format_patient_status(status):
        if status == 0:
            return "Normal"
        elif status == 1:
            return "Urgent"
        return "Super-Urgent"
