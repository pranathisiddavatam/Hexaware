import pyodbc

conn = pyodbc.connect(
    'DRIVER={SQL SERVER};'
    'SERVER=PRANATHI;'
    'DATABASE=LibraryDB;'
    'Trusted_Connection=yes;'
)
cursor = conn.cursor()