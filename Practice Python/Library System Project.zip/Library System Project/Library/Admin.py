from Library.connection import conn, cursor
from Library.Book import Book
from Library.User import User

class Admin:
    def add_book(self, book_id, book_name, book_quantity):
        cursor.execute("SELECT * FROM Books WHERE BookID = ?", book_id)
        if cursor.fetchone():
            print("This book already exists")
            return
        cursor.execute("INSERT INTO Books (BookID, BookName, Quantity) VALUES (?, ?, ?)",
                       book_id, book_name, int(book_quantity))
        conn.commit()
        print("Book added successfully")

    def print_all_books(self):
        cursor.execute("SELECT BookName FROM Books")
        books = cursor.fetchall()
        if not books:
            return "There are no books"
        return ", ".join([book[0] for book in books])

    def search_for_book(self, query):
        cursor.execute("SELECT BookName FROM Books WHERE BookName LIKE ?", query + '%')
        found_books = [row[0] for row in cursor.fetchall()]
        if not found_books:
            return ["No book found"]
        return found_books

    def add_user(self, user_id, user_name):
        cursor.execute("SELECT * FROM Users WHERE UserID = ?", user_id)
        if cursor.fetchone():
            print("This user already exists!")
            return
        cursor.execute("INSERT INTO Users (UserID, UserName) VALUES (?, ?)", user_id, user_name)
        conn.commit()
        print("User created successfully!")

    def borrow_book(self, user_name, book_name):
        cursor.execute("SELECT UserID FROM Users WHERE UserName = ?", user_name)
        user = cursor.fetchone()
        if not user:
            print("User not found")
            return

        user_id = user[0]

        cursor.execute("SELECT Quantity FROM Books WHERE BookName = ?", book_name)
        book = cursor.fetchone()
        if not book:
            print("Book not found")
            return

        if book[0] <= 0:
            print("Insufficient quantity!")
            return

        cursor.execute("INSERT INTO BorrowedBooks (UserID, BookName) VALUES (?, ?)", user_id, book_name)
        cursor.execute("UPDATE Books SET Quantity = Quantity - 1 WHERE BookName = ?", book_name)
        conn.commit()
        print(f"The user {user_name} borrowed {book_name}")

    def return_book(self, user_name, book_name):
        cursor.execute("SELECT UserID FROM Users WHERE UserName = ?", user_name)
        user = cursor.fetchone()
        if not user:
            print("User not found")
            return
        user_id = user[0]

        cursor.execute("DELETE FROM BorrowedBooks WHERE UserID = ? AND BookName = ?", user_id, book_name)
        if cursor.rowcount == 0:
            print("No such borrowed book found")
            return

        cursor.execute("UPDATE Books SET Quantity = Quantity + 1 WHERE BookName = ?", book_name)
        conn.commit()
        print(f"The user {user_name} returned {book_name}")

    def print_users_borrowed(self):
        cursor.execute("""
            SELECT u.UserName, b.BookName 
            FROM Users u 
            JOIN BorrowedBooks b ON u.UserID = b.UserID
        """)
        results = cursor.fetchall()
        if results:
            from collections import defaultdict
            data = defaultdict(list)
            for user, book in results:
                data[user].append(book)
            for user, books in data.items():
                print(f"{user} borrowed: {', '.join(books)}")
        else:
            print("No users have borrowed any books")

    def print_all_users(self):
        cursor.execute("SELECT UserName FROM Users")
        users = [row[0] for row in cursor.fetchall()]
        if users:
            print(" ".join(users))
        else:
            print("No users available.")
